
# $pojazd = input("Podaj typ pojazdu: rower, samochód, samolot, pociąg, statek")

# nazwa = input("Nazwa pojazdu") #np. Boeing 777

# pasazer = input("Imię i nazwisko pasażera") #np. Dmitrij Popow

# cel = input("Cel podróży") #np. Moskwa

# print(Pasazer, "chce się dostać do:", cel)

# print("za pomocą pojazdu typu:", $pojazd)

# print("o nazwie:", nazwa)

print("2;10;12")